import streamlit as st
import langchain_helper

st.write('SHOW ROOM Name and different cars in it Genererator')
cars=st.sidebar.selectbox('Pick a Car',('Toyota','Mercedes','BMW','Lexus','Suzuki','Honda'))


if cars:
    response=langchain_helper.generate_showroom_name_and_cars(cars)
    st.header(response['showroom_name'].strip())
    diff_cars=response['car_names'].strip().split(',')
    st.write('Cars:')
    for item in diff_cars:
        st.write('-',item)