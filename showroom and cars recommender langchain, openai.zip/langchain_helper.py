from langchain_community.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import os
from langchain.chains import SequentialChain

llm=OpenAI(temperature=0.7)
api_key=os.getenv('OPENAI_API_KEY')


def generate_showroom_name_and_cars(cars):
    prompt1=PromptTemplate(
    input_variables=["cars"],
    template="I want to open a showroom of {cars} cars. Suggest me a fancy name for it."
    )
    chain1 = LLMChain(
        llm=llm,
        prompt=prompt1,
        output_key='showroom_name'
    )
    prompt2=PromptTemplate(
        input_variables=['showroon_name'],
        template='Tell me different types of {cars} that should be featured in the showroom named {showroom_name}'
    )
    chain2 = LLMChain(
        llm=llm,
        prompt=prompt2,
        output_key='car_names'
    )
    chain=SequentialChain(chains = [chain1,chain2], input_variables=['cars'],output_variables=['showroom_name','car_names'])
    response=chain({'cars':cars})
    return response